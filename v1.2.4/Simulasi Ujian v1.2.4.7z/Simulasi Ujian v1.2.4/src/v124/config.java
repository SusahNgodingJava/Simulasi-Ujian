/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v124;

/**
 * standard font soal: cambria
 * @author Susah Ngoding Java
 */
public class config extends javax.swing.JFrame {

    static java.awt.Point point;
    private String
    tamp,
    dir="C:\\xampp";
    public final String
    pilih[]={"Ya", "Tidak"},
    kunci[]={"a", "b", "c", "d"},
    ALPHA="\u03b1",//α
    BETA="\u03b2",//β
    DELTA="\u0394",//Δ
    GAMMA="\u03b3",//γ
    INTEGRAL="\u0283",//ʃ
    LAMDA="\u03bb",//λ
    MU="\u03bc",//μ
    OHM="\u03a9",//Ω
    OMEGA="\u03c9",//ω
    PI="\u03c0",//π
    PLUS_MINUS="\u00b1",//±
    RHO="\u03c1",//ρ
    SIGMA="\u03a3",//Σ
    THETA="\u03b8";//θ

    //ALPHA+BETA+DELTA+GAMMA+INTEGRAL+LAMDA+MU+OHM+OMEGA+PI+PLUS_MINUS+RHO+SIGMA+THETA

    private String logtime(){
        java.util.Calendar thetime = java.util.Calendar.getInstance();
        
        return "["+thetime.get(java.util.Calendar.HOUR)+":"+thetime.get(java.util.Calendar.MINUTE)+":"+thetime.get(java.util.Calendar.SECOND)+"]";
    }
    
    private String logdate(){
        java.util.Calendar thetime = java.util.Calendar.getInstance();
    
        return "["+day()+" "+thetime.get(java.util.Calendar.DATE)+" "+month()+" "+thetime.get(java.util.Calendar.YEAR)+"]";
    }

    public boolean logincheck(String user, String passw){
        try(java.io.BufferedReader ambil = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(new java.io.File("..\\Simulasi Ujian v1.2.4\\src\\v124\\data.csv"))))){
            for(int i=0; i<4; i++){
                java.util.StringTokenizer split = new java.util.StringTokenizer(ambil.readLine(), ",");
                split.nextToken();
                if(user.equals(split.nextToken()) && passw.equals(split.nextToken())){
                    return true;
                }
            }
        }
        catch(java.io.FileNotFoundException ex){
            return false;
        }
        catch(java.io.IOException ex) {

        }
        return false;
    }

    public void logwrite(String kalimat){
        //try (java.io.BufferedWriter tulis = new java.io.BufferedWriter(new java.io.FileWriter(log, true))) {
        try (java.io.BufferedWriter tulis = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(new java.io.File(dir+"\\log.suf"), true), "UTF-16"));){
            tulis.write(logdate()+" "+logtime()+" "+kalimat);
            tulis.newLine();
            tulis.flush();
        }
        catch (java.io.IOException ex) {

        }
    }

    public void scorewrite(String bil){
        //try (java.io.BufferedWriter temp = new java.io.BufferedWriter(new java.io.FileWriter(score, false))) {
        try (java.io.BufferedWriter temp = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(new java.io.File(dir+"\\score.suf"), false), "UTF-16"))){
            temp.write(String.valueOf(bil));
            temp.flush();
        }
        catch (java.io.IOException ex) {

        }
    }

    public float scoreread() throws java.io.IOException{
        //try (java.io.BufferedReader ambil = new java.io.BufferedReader(new java.io.FileReader(score))) {
        try(java.io.BufferedReader ambil = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(new java.io.File(dir+"\\score.suf")), "UTF-16"))){
            java.util.StringTokenizer split = new java.util.StringTokenizer(ambil.readLine(), "Nilai=");
            return Float.valueOf(split.nextToken());
        }
    }

    public boolean scoreexist(){
        return new java.io.File(dir+"\\score.suf").exists();
    }

    public void scoredelete(){
        new java.io.File(dir+"\\score.suf").delete();
    }

    public String format(float bil){
        java.text.DecimalFormat koma = new java.text.DecimalFormat("###.##");

        return koma.format(bil);
    }

    public boolean direxist(){
        return new java.io.File(dir).exists();
    }

    public void dircreate(){
        new java.io.File(dir).mkdirs();
    }

    private String day(){
        java.util.Calendar thetime = java.util.Calendar.getInstance();
        
        switch(thetime.get(java.util.Calendar.DAY_OF_WEEK)){
            case 1:
            return "Minggu";
            
            case 2:
            return "Senin";
            
            case 3:
            return "Selasa";
            
            case 4:
            return "Rabu";
            
            case 5:
            return "Kamis";
            
            case 6:
            return "Jumat";
            
            case 7:
            return "Sabtu";
        }
        return "";
    }
    
    private String month(){
        java.util.Calendar thetime = java.util.Calendar.getInstance();
        
        switch(thetime.get(java.util.Calendar.MONTH)+1){
            case 1:
            tamp="Januari";
            break;
            
            case 2:
            tamp="Pebruari";
            break;
            
            case 3:
            tamp="Maret";
            break;
            
            case 4:
            tamp="April";
            break;
            
            case 5:
            tamp="Mei";
            break;
            
            case 6:
            tamp="Juni";
            break;
            
            case 7:
            tamp="Juli";
            break;
            
            case 8:
            tamp="Agustus";
            break;
            
            case 9:
            tamp="September";
            break;
            
            case 10:
            tamp="Oktober";
            break;
            
            case 11:
            tamp="Nopember";
            break;
            
            case 12:
            tamp="Desember";
            break;
        }
        return tamp;
    }

    public String indeks(String bil){
        tamp="";
        for(int wal=0; wal<bil.length(); wal++){
            switch(String.valueOf(bil.charAt(wal))){
                case "-":
                tamp=tamp+"\u208B";//₋
                break;

                case "+":
                tamp=tamp+"\u208A";//₊
                break;

                case "0":
                tamp=tamp+"\u2080";//₀
                break;

                case "1":
                tamp=tamp+"\u2081";//₁
                break;

                case "2":
                tamp=tamp+"\u2082";//₂
                break;

                case "3":
                tamp=tamp+"\u2083";//₃
                break;

                case "4":
                tamp=tamp+"\u2084";//₄
                break;

                case "5":
                tamp=tamp+"\u2085";//₅
                break;

                case "6":
                tamp=tamp+"\u2086";//₆
                break;

                case "7":
                tamp=tamp+"\u2087";//₇
                break;

                case "8":
                tamp=tamp+"\u2088";//₈
                break;

                case "9":
                tamp=tamp+"\u2089";//₉
                break;
            }
        }
        return tamp;
    }
    
    public String pangkat(String bil){
        tamp="";
        for(int wal=0; wal<bil.length(); wal++){
            switch(String.valueOf(bil.charAt(wal))){
                case "-":
                tamp=tamp+"\u207b";//⁻
                break;

                case "+":
                tamp=tamp+"\u207a";//⁺
                break;

                case "0":
                tamp=tamp+"\u2070";//⁰
                break;

                case "1":
                tamp=tamp+"\u00b9";//¹
                break;

                case "2":
                tamp=tamp+"\u00b2";//²
                break;

                case "3":
                tamp=tamp+"\u00b3";//³
                break;

                case "4":
                tamp=tamp+"\u2074";//⁴
                break;

                case "5":
                tamp=tamp+"\u2075";//⁵
                break;

                case "6":
                tamp=tamp+"\u2076";//⁶
                break;

                case "7":
                tamp=tamp+"\u2077";//⁷
                break;

                case "8":
                tamp=tamp+"\u2078";//⁸
                break;

                case "9":
                tamp=tamp+"\u2079";//⁹
                break;
            }
        }
        return tamp;
    }
}