/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v113;

import java.io.IOException;

/**
 * standard font soal: cambria
 * @author Susah Ngoding Java
 */
public class config extends javax.swing.JFrame {
    java.io.File score = new java.io.File("C:\\xampp\\score.suf");
    java.io.File log = new java.io.File("C:\\xampp\\log.suf");
    java.io.File stats = new java.io.File("C:\\xampp\\stats");

    static java.awt.Point point;
    private String time, kode="";
    String
    kunci[]={"a", "b", "c", "d"},
    ALPHA="\u03b1",//α
    BETA="\u03b2",//β
    DELTA="\u0394",//Δ
    GAMMA="\u03b3",//γ
    LAMDA="\u03bb",//λ
    MU="\u03bc",//μ
    OMEGA="\u03c9",//ω
    OHM="\u03a9",//Ω
    PI="\u03c0",//π
    RHO="\u03c1",//ρ
    SIGMA="\u03a3",//Σ
    THETA="\u03b8";//θ

    /*
    ALPHA+BETA+DELTA+GAMMA+LAMDA+MU+OMEGA+OHM+PI+RHO+SIGMA+THETA
    */

    public String logtime(){
        java.util.Calendar thetime = java.util.Calendar.getInstance();
        
        return "["+thetime.get(java.util.Calendar.HOUR)+":"+thetime.get(java.util.Calendar.MINUTE)+":"+thetime.get(java.util.Calendar.SECOND)+"]";
    }
    
    public String logdate(){
        java.util.Calendar thetime = java.util.Calendar.getInstance();
    
        return "["+day()+" "+thetime.get(java.util.Calendar.DATE)+" "+month()+" "+thetime.get(java.util.Calendar.YEAR)+"]";
    }

    public void logwrite(String kalimat) throws IOException{
        //try (java.io.BufferedWriter tulis = new java.io.BufferedWriter(new java.io.FileWriter(log, true))) {
        try (java.io.BufferedWriter tulis = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(log, true),"UTF-16"));){
            tulis.write(logdate()+" "+logtime()+" "+kalimat);
            tulis.newLine();
            tulis.flush();
        }
    }

    public void scorewrite(String bil) throws IOException{
        //try (java.io.BufferedWriter temp = new java.io.BufferedWriter(new java.io.FileWriter(score, false))) {
        try (java.io.BufferedWriter temp = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(score, false),"UTF-16"));){
            temp.write(String.valueOf(bil));
            temp.flush();
        }
    }

    public float scoreread() throws IOException{
        //try (java.io.BufferedReader ambil = new java.io.BufferedReader(new java.io.FileReader(score))) {
        try(java.io.BufferedReader ambil = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(score),"UTF-16"));){
                java.util.StringTokenizer split = new java.util.StringTokenizer(ambil.readLine(), "Nilai=");
                return Float.valueOf(split.nextToken());
            }
    }

    public String format(float bil){
        java.text.DecimalFormat koma = new java.text.DecimalFormat("###.##");

        return koma.format(bil);
    }
    
    public String day(){
        java.util.Calendar thetime = java.util.Calendar.getInstance();
        
        switch(thetime.get(java.util.Calendar.DAY_OF_WEEK)){
            case 1:
            time="Minggu";
            break;
            
            case 2:
            time="Senin";
            break;
            
            case 3:
            time="Selasa";
            break;
            
            case 4:
            time="Rabu";
            break;
            
            case 5:
            time="Kamis";
            break;
            
            case 6:
            time="Jumat";
            break;
            
            case 7:
            time="Sabtu";
            break;
        }
        return time;
    }
    
    public String month(){
        java.util.Calendar thetime = java.util.Calendar.getInstance();
        
        switch(thetime.get(java.util.Calendar.MONTH)+1){
            case 1:
            time="Januari";
            break;
            
            case 2:
            time="Pebruari";
            break;
            
            case 3:
            time="Maret";
            break;
            
            case 4:
            time="April";
            break;
            
            case 5:
            time="Mei";
            break;
            
            case 6:
            time="Juni";
            break;
            
            case 7:
            time="Juli";
            break;
            
            case 8:
            time="Agustus";
            break;
            
            case 9:
            time="September";
            break;
            
            case 10:
            time="Oktober";
            break;
            
            case 11:
            time="Nopember";
            break;
            
            case 12:
            time="Desember";
            break;
        }
        return time;
    }

    public String indeks(String bil){
        for(int wal=0; wal<bil.length(); wal++){
            switch(String.valueOf(bil.charAt(wal))){
                case "-":
                kode=kode+"\u208B";//₋
                break;

                case "+":
                kode=kode+"\u208A";//₊
                break;

                case "0":
                kode=kode+"\u2080";//₀
                break;

                case "1":
                kode=kode+"\u2081";//₁
                break;

                case "2":
                kode=kode+"\u2082";//₂
                break;

                case "3":
                kode=kode+"\u2083";//₃
                break;

                case "4":
                kode=kode+"\u2084";//₄
                break;

                case "5":
                kode=kode+"\u2085";//₅
                break;

                case "6":
                kode=kode+"\u2086";//₆
                break;

                case "7":
                kode=kode+"\u2087";//₇
                break;

                case "8":
                kode=kode+"\u2088";//₈
                break;

                case "9":
                kode=kode+"\u2089";//₉
                break;
            }
        }
        return kode;
    }
    
    public String pangkat(String bil){
        for(int wal=0; wal<bil.length(); wal++){
            switch(String.valueOf(bil.charAt(wal))){
                case "-":
                kode=kode+"\u207b";//⁻
                break;

                case "+":
                kode=kode+"\u207a";//⁺
                break;

                case "0":
                kode=kode+"\u2070";//⁰
                break;

                case "1":
                kode=kode+"\u00b9";//¹
                break;

                case "2":
                kode=kode+"\u00b2";//²
                break;

                case "3":
                kode=kode+"\u00b3";//³
                break;

                case "4":
                kode=kode+"\u2074";//⁴
                break;

                case "5":
                kode=kode+"\u2075";//⁵
                break;

                case "6":
                kode=kode+"\u2076";//⁶
                break;

                case "7":
                kode=kode+"\u2077";//⁷
                break;

                case "8":
                kode=kode+"\u2078";//⁸
                break;

                case "9":
                kode=kode+"\u2079";//⁹
                break;
            }
        }
        return kode;
    }
}