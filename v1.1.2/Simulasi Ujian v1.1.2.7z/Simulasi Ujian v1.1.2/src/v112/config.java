/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package v112;

import java.io.IOException;

/**
 * standard font soal: cambria
 * @author Susah Ngoding Java
 */
public class config extends javax.swing.JFrame {
    java.io.File score = new java.io.File("C:\\xampp\\nilai.txt");
    java.io.File log = new java.io.File("C:\\xampp\\log.txt");

    private String kode="";
    String
    kunci[]={"a", "b"},
    ALPHA="\u03b1",//α
    BETA="\u03b2",//β
    DELTA="\u0394",//Δ
    GAMMA="\u03b3",//γ
    LAMDA="\u03bb",//λ
    MU="\u03bc",//μ
    OMEGA="\u03c9",//ω
    OHM="\u03a9",//Ω
    PI="\u03c0",//π
    RHO="\u03c1",//ρ
    SIGMA="\u03a3",//Σ
    THETA="\u03b8";//θ
    
    /*
    ALPHA+BETA+DELTA+GAMMA+LAMDA+MU+OMEGA+OHM+PI+RHO+SIGMA+THETA
    */
    
    public String logtime(){
        java.util.GregorianCalendar time = new java.util.GregorianCalendar();

        return "["+time.getTime().getHours()+":"+time.getTime().getMinutes()+":"
                +time.getTime().getSeconds()+"]";
    }

    public void logwrite(String kalimat) throws IOException{
        try (java.io.BufferedWriter tulis = new java.io.BufferedWriter(
            new java.io.FileWriter(log, true))) {
            tulis.write(logtime()+" "+kalimat);
            tulis.newLine();
            tulis.flush();
        }
    }
    
    public void scorewrite(float bil) throws IOException{
        try (java.io.BufferedWriter temp = new java.io.BufferedWriter(
            new java.io.FileWriter(score, false))) {
            temp.write(String.valueOf(bil));
            temp.flush();
        }
    }
    
    public float scoreread() throws IOException{
        float nilai;
        try (java.io.BufferedReader ambil = new java.io.BufferedReader(new java.io.FileReader(score))) {
                nilai=Float.valueOf(ambil.readLine());
            }
        return nilai;
    }
    
    public String format(float bil){
        java.text.DecimalFormat koma = new java.text.DecimalFormat("###.##");

        return koma.format(bil);
    }

    public String indeks(String bil){
        for(int wal=0; wal<bil.length(); wal++){
            switch(String.valueOf(bil.charAt(wal))){
                case "-":
                kode=kode+"₋";
                break;

                case "+":
                kode=kode+"₊";
                break;

                case "0":
                kode=kode+"₀";
                break;

                case "1":
                kode=kode+"₁";
                break;

                case "2":
                kode=kode+"₂";
                break;

                case "3":
                kode=kode+"₃";
                break;

                case "4":
                kode=kode+"₄";
                break;

                case "5":
                kode=kode+"₅";
                break;

                case "6":
                kode=kode+"₆";
                break;

                case "7":
                kode=kode+"₇";
                break;

                case "8":
                kode=kode+"₈";
                break;

                case "9":
                kode=kode+"₉";
                break;
            }
        }
        return kode;
    }
    
    public String pangkat(String bil){
        for(int wal=0; wal<bil.length(); wal++){
            switch(String.valueOf(bil.charAt(wal))){
                case "-":
                kode=kode+"\u207b";//⁻
                break;

                case "+":
                kode=kode+"\u207a";//⁺
                break;

                case "0":
                kode=kode+"\u2070";//⁰
                break;

                case "1":
                kode=kode+"\u00b9";//¹
                break;

                case "2":
                kode=kode+"\u00b2";//²
                break;

                case "3":
                kode=kode+"\u00b3";//³
                break;

                case "4":
                kode=kode+"\u2074";//⁴
                break;

                case "5":
                kode=kode+"\u2075";//⁵
                break;

                case "6":
                kode=kode+"\u2076";//⁶
                break;

                case "7":
                kode=kode+"\u2077";//⁷
                break;

                case "8":
                kode=kode+"\u2078";//⁸
                break;

                case "9":
                kode=kode+"\u2079";//⁹
                break;
            }
        }
        return kode;
    }
}
